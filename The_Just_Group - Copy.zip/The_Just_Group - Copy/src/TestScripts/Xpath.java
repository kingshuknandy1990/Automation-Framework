package TestScripts;

public class Xpath {
	
	public static String  userName = "ContentPlaceHolder1_UsernameTextBox";
	public static String  passWord = "//*[@id='ContentPlaceHolder1_PasswordTextBox']";
	public static String  loginButton = "html/body/form/div[3]/div[3]/table/tbody/tr/td[2]/fieldset/table/tbody/tr[4]/td[1]/div/input";

}
